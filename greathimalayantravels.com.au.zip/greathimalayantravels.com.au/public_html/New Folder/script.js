document.addEventListener('DOMContentLoaded', function() {
    const serviceSelect = document.getElementById('service');
    const flightOptions = document.getElementById('flightOptions');

    serviceSelect.addEventListener('change', function() {
        if (serviceSelect.value === 'flight') {
            flightOptions.classList.remove('hidden');
        } else {
            flightOptions.classList.add('hidden');
        }
    });

    document.getElementById('contactForm').onsubmit = function(e) {
        e.preventDefault();
        alert('Thank you for your submission! We will get back to you soon.');
    };
});
