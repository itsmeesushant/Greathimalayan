const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/submit', (req, res) => {
    const { fullName, address, phoneNumber, service, from, to, dateTravel } = req.body;

    // Set up Nodemailer transport
    const transporter = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
            user: 'your-email@gmail.com',
            pass: 'your-email-password'
        }
    });

    const mailOptions = {
        from: 'your-email@gmail.com',
        to: 'admin-email@gmail.com',
        subject: 'New Form Submission',
        text: `New form submission from ${fullName}.\n\nAddress: ${address}\nPhone Number: ${phoneNumber}\nService: ${service}\nFrom: ${from}\nTo: ${to}\nDate of Travel: ${dateTravel}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error occurred:', error);
            return res.status(500).send('Internal Server Error');
        }
        res.status(200).send('Form submitted successfully');
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
